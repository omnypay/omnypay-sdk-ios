//
//  OmnyPayAPI.h
//  OmnyPayAPI
//
//  Created by Tarun Sharma on 25/08/16.
//  Copyright © 2016 OmnyPay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OmnyPayAPI.
FOUNDATION_EXPORT double OmnyPayAPIVersionNumber;

//! Project version string for OmnyPayAPI.
FOUNDATION_EXPORT const unsigned char OmnyPayAPIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OmnyPayAPI/PublicHeader.h>


