//
//  OmnyPayScan.h
//  OmnyPayScan
//
//  Created by Saurabh Goyal on 16/08/16.
//  Copyright © 2016 OmnyPay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OmnyPayScan.
FOUNDATION_EXPORT double OmnyPayScanVersionNumber;

//! Project version string for OmnyPayScan.
FOUNDATION_EXPORT const unsigned char OmnyPayScanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OmnyPayScan/PublicHeader.h>


